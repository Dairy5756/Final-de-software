
USE Dairy111;

-- Creaci�n de la tabla Libros
CREATE TABLE Libros (
    ISBN VARCHAR(20) PRIMARY KEY,
    Titulo VARCHAR(100) NOT NULL,
    Autor VARCHAR(100),
    Editorial VARCHAR(100),
    AnoPublicacion INT,
    Genero VARCHAR(50),
    NumeroCopias INT
);

-- Creaci�n de la tabla Usuarios
CREATE TABLE Usuarios (
    UsuarioID INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Telefono VARCHAR(15)
);

-- Creaci�n de la tabla Reservas
CREATE TABLE Reservas (
    ReservaID INT PRIMARY KEY IDENTITY(1,1),
    UsuarioID INT,
    ISBN VARCHAR(20),
    FechaReserva DATE NOT NULL,
    FechaRetorno DATE,
    FOREIGN KEY (UsuarioID) REFERENCES Usuarios(UsuarioID),
    FOREIGN KEY (ISBN) REFERENCES Libros(ISBN)
);

-- Inserci�n de libros
INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, AnoPublicacion, Genero, NumeroCopias)
VALUES 
('9780451524935', '1984', 'George Orwell', 'Secker & Warburg', 1949, 'Distop�a', 5),
('9780439139601', 'Harry Potter and the Goblet of Fire', 'J.K. Rowling', 'Bloomsbury', 2000, 'Fantas�a', 10),
('9780140449266', 'Los Miserables', 'Victor Hugo', 'Penguin Classics', 1862, 'Cl�sico', 3),
('9780307277671', 'El C�digo Da Vinci', 'Dan Brown', 'Doubleday', 2003, 'Thriller', 7),
('9780316769488', 'El guardi�n entre el centeno', 'J.D. Salinger', 'Little, Brown and Company', 1951, 'Ficci�n', 4);

-- Inserci�n de usuarios
INSERT INTO Usuarios (Nombre, Apellido, Email, Telefono)
VALUES 
('Juan', 'P�rez', 'juan.perez@example.com', '809-555-1234'),
('Mar�a', 'Gonz�lez', 'maria.gonzalez@example.com', '809-555-5678'),
('Luis', 'Mart�nez', 'luis.martinez@example.com', '809-555-4321'),
('Ana', 'Rodr�guez', 'ana.rodriguez@example.com', '809-555-8765'),
('Pedro', 'Fern�ndez', 'pedro.fernandez@example.com', '809-555-3456');

-- Inserci�n de reservas
INSERT INTO Reservas (UsuarioID, ISBN, FechaReserva, FechaRetorno)
VALUES 
(1, '9780451524935', '2024-10-01', '2024-10-15'),
(2, '9780439139601', '2024-10-05', '2024-10-19'),
(3, '9780140449266', '2024-10-03', '2024-10-17'),
(4, '9780307277671', '2024-10-02', '2024-10-16'),
(5, '9780316769488', '2024-10-07', '2024-10-21');

-- Consulta para contar reservas por usuario
SELECT u.Nombre, u.Apellido, COUNT(r.ReservaID) AS ReservasRealizadas
FROM Reservas r
JOIN Usuarios u ON r.UsuarioID = u.UsuarioID
GROUP BY u.Nombre, u.Apellido
ORDER BY ReservasRealizadas DESC;
